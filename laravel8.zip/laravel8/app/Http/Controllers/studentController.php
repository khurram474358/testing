<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\student;
use App\Models\studentDetail;
class studentController extends Controller
{
    public function addStudent(){
    	return view('addstudent');
    }

    public function addStudentDb(Request $req){
    	

    	$validator= Validator::make($req->all(),[
    		'fname'=>'required|min:4',
    		'lname'=>'required|min:4'
    	]);
    	if ($validator->fails()) {

    		return redirect('add')->withErrors($validator)->withInput();
    	}

    	$student= new student;
    	$student->_token=$req->_token;
    	$student->fname=$req->fname;
    	$student->lname=$req->lname;
    	$student->save();
    	$id=$student->id;
    	return redirect('detail')->with('id',$id);

    }
    public function addStudentDetail(){
    	// return Session::get('id');
    	// return $id;

    	return view('detail');
    }



    public function addStudentDetailDb(Request $req){
    	$student = new studentDetail;
    	$student->student_id=$req->student_id;
    	$student->age=$req->age;
    	$student->phone_no=$req->phone_no;
    	$student->address=$req->address;
    	$student->qualification=$req->qualification;
    	$student->save();
    	return "data has been inserted";


    }

    public function show(){
        return student::all();
    }
}
